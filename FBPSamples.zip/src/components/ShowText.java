package components;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.lang.reflect.InvocationTargetException;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

import com.jpmorrsn.fbp.engine.*;

/**
 * Component to write data to a Swing pane. The title comes in at another port. It is specified as "must run". Incoming packets are
 * sent to output port.
 */
@ComponentDescription("Displays packets on Swing EditorPane")
@MustRun
@InPorts( { 
	@InPort(value="IN", description="Packets to be displayed", type=String.class), 
	@InPort(value="TITLE", description="Title string", type=String.class) })
@OutPort(value = "OUT", optional = true, description="Output port, if connected", type=String.class)
public class ShowText extends Component /* implements MustRun */{

  static final String copyright = "Copyright 2007, 2008, J. Paul Morrison.  At your option, you may copy, "
      + "distribute, or make derivative works under the terms of the Clarified Artistic License, "
      + "based on the Everything Development Company's Artistic License.  A document describing "
      + "this License may be found at http://www.jpaulmorrison.com/fbp/artistic2.htm. "
      + "THERE IS NO WARRANTY; USE THIS PRODUCT AT YOUR OWN RISK.";

  InputPort inport, titleport;

  JFrame jframe;

  OutputPort outport;

  String title = "Data Pane";

  JEditorPane jEditorPane;

  @Override
  protected void execute() {
    Packet tp = titleport.receive();
    if (tp != null) {
      title = (String) tp.getContent();
      drop(tp);
      titleport.close();
    }

    // start up the swing ui in a separate thread ....
    try {
      SwingUtilities.invokeAndWait(new Runnable() {

        public void run() {
          jframe = new JFrame(title);
          jEditorPane = new JEditorPane("text/plain", " ");
          jEditorPane.setEditable(false);
          JScrollPane scrollPane = new JScrollPane(jEditorPane);
          jframe.add(scrollPane);
          jframe.setVisible(true);
          jframe.setSize(600, 400);
          jframe.setLocation(100, 50);
          jframe.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(final WindowEvent ev) {
              jframe.dispose();
            }
          });
        }
      });
    } catch (InterruptedException e) {
      e.printStackTrace();
    } catch (InvocationTargetException e) {
      e.printStackTrace();
    }

    String contents = "";
    Packet p;
    while ((p = inport.receive()) != null) {
      String s = "" + p.getContent();
      contents += s + "\n";
      if (outport.isConnected()) {
        outport.send(p);
      } else {
        drop(p);
      }
      longWaitStart(2.0); // timeout if over 2 secs
      jEditorPane.setText(contents);
      jframe.update(jframe.getGraphics());
      longWaitEnd();
    }
  }
/*
  @Override
  public Object[] introspect() {
    return new Object[] { "transmits its input to a JEditorPane as lines", "IN", "input", Object.class,
        "lines to be written", "TITLE", "input", String.class, "title of pane", "OUT", "output, optional",
        Object.class, "output packets" };
  }
*/
  @Override
  protected void openPorts() {
    inport = openInput("IN");

    outport = openOutput("OUT");
    titleport = openInput("TITLE");
  
  }
}
