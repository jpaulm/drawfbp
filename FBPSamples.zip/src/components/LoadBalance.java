package components;

import com.jpmorrsn.fbp.engine.*;



/** Component to assign incoming packets to the output port that has the
* smallest backlog of packets waiting to be processed.
*/
@ComponentDescription("Sends incoming packets to output array element with smallest backlog")
@OutPort(value="OUT", arrayPort = true, description="Packets being output") 
@InPort(value="IN", description="Incoming packets")
public class LoadBalance extends Component {

static final String copyright = 
"Copyright 2007, 2008, J. Paul Morrison.  At your option, you may copy, " +
"distribute, or make derivative works under the terms of the Clarified Artistic License, " +
"based on the Everything Development Company's Artistic License.  A document describing " +
"this License may be found at http://www.jpaulmorrison.com/fbp/artistic2.htm. " +
"THERE IS NO WARRANTY; USE THIS PRODUCT AT YOUR OWN RISK.";



	InputPort inport;
	OutputPort[] outportArray;

	protected void execute() {

		int no = outportArray.length;
		int backlog;
		int sel = -1;

	    Packet p;
		while ((p = inport.receive()) != null) {
			backlog = Integer.MAX_VALUE;
			for (int i = 0; i < no; i++) {
			    int j = outportArray[i].downstreamCount();
			    if (j < backlog) {
				    backlog = j;
				    sel = i;
			        }
			    }
			    outportArray[sel].send(p);

			}
	}
	/*
	public Object[] introspect() {
		return new Object[] {
		"obtains input stream at port IN and distributes them to array port OUT" +
		" depending on which output port has the smallest backlog" ,
		"IN", "input", Object.class,
			"input stream",
		"OUT", "output, array", Object.class,
			"multiple output streams"};
		}
	*/
	protected void openPorts() {

		inport = openInput("IN");
		
		outportArray = openOutputArray("OUT");

		}
}
