package components;

import com.jpmorrsn.fbp.engine.*;



/** Component to generate a single packet - mostly used for debugging.
*/
@ComponentDescription("Outputs single packet containing blank")
@OutPort(value="OUT", description="Single packet containing blank", type=String.class) 

public class Kick extends Component {

static final String copyright = 
"Copyright 2007, 2008, J. Paul Morrison.  At your option, you may copy, " +
"distribute, or make derivative works under the terms of the Clarified Artistic License, " +
"based on the Everything Development Company's Artistic License.  A document describing " +
"this License may be found at http://www.jpaulmorrison.com/fbp/artistic2.htm. " +
"THERE IS NO WARRANTY; USE THIS PRODUCT AT YOUR OWN RISK.";



	OutputPort outport;


	protected void execute()  {

		Packet p = create(" ");
		outport.send(p);


		}
	/*
	public Object[] introspect() {
		return new Object[] {
		"provides a null Packet to start a loop",
		"OUT", "output", null,
			"packet produced"};
		}
	*/
	protected void openPorts() {
		outport = openOutput("OUT");
		}
}
