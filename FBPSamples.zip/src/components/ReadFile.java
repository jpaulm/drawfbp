package components;

import com.jpmorrsn.fbp.engine.*;

import java.io.*;

/**
 * Component to read data from a file, generating a stream of packets. The file
 * name is specified as a String via an InitializationConnection.
 */
@ComponentDescription("Generate stream of packets from I/O file")
@OutPort(value="OUT", description="Generated packets", type=String.class)
@InPort(value="SOURCE", description="File name", type=String.class)
public class ReadFile extends Component {

	static final String copyright = "Copyright 2007, 2008, 2009, J. Paul Morrison.  At your option, you may copy, "
			+ "distribute, or make derivative works under the terms of the Clarified Artistic License, "
			+ "based on the Everything Development Company's Artistic License.  A document describing "
			+ "this License may be found at http://www.jpaulmorrison.com/fbp/artistic2.htm. "
			+ "THERE IS NO WARRANTY; USE THIS PRODUCT AT YOUR OWN RISK.";

	OutputPort outport;

	InputPort source;

	protected void execute() {
		Packet rp = source.receive();
		if (rp == null) {
			return;
		}
		source.close();

		String sf = (String) (rp.getContent());
		try {
			drop(rp);
			BufferedReader b = new BufferedReader(new FileReader(sf));
			String s;
			while ((s = b.readLine()) != null) {
				Packet p = create(s);
				// System.out.println("RT" + p.getContent());
				outport.send(p);
			}
			b.close();
		} catch (IOException e) {
			System.out.println("I/O Error on file: " + sf);
		}
	}
/*
	public Object[] introspect() {
		return new Object[] {
				"reads input from a java.io.Reader "
						+ "(a character stream) and outputs it line-by-line",
				"OUT", "output", String.class, "lines read", "SOURCE",
				"parameter", String.class, "File name" };
	}
	*/

	protected void openPorts() {

		outport = openOutput("OUT");
	

		source = openInput("SOURCE");
	

	}
}
