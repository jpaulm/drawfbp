package components;

import com.jpmorrsn.fbp.engine.*;

/**
 * Component to pass packets through with random delay.
 */
@ComponentDescription("Delays incoming packets for random amount of time (0 - 2 secs.)")
@OutPort(value="OUT", description="Packets being output")
@InPort(value="IN", description="Incoming packets")
public class RandomDelay extends Component {

	static final String copyright = "Copyright 2007, 2008, J. Paul Morrison.  At your option, you may copy, "
			+ "distribute, or make derivative works under the terms of the Clarified Artistic License, "
			+ "based on the Everything Development Company's Artistic License.  A document describing "
			+ "this License may be found at http://www.jpaulmorrison.com/fbp/artistic2.htm. "
			+ "THERE IS NO WARRANTY; USE THIS PRODUCT AT YOUR OWN RISK.";

	InputPort inport;
	OutputPort outport;

	protected void execute()  {

		Packet p;
		while ((p = inport.receive()) != null) {
			long r = new Double(Math.random()).longValue();
			long rl = 2000 * r; // range is from 0 to 2 secs
			try {
			Thread.sleep(rl);
			} catch (InterruptedException e){
				
			}
			outport.send(p);
		}
	}
 /*
	public Object[] introspect() {
		return new Object[] { "passes packets through with random delay", "IN",
				"input", Object.class, "input stream", "OUT", "output",
				Object.class, "output stream" };
	}
	 */

	protected void openPorts() {

		inport = openInput("IN");
	

		outport = openOutput("OUT");

	}
}
