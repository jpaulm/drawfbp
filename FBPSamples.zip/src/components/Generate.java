package components;
import com.jpmorrsn.fbp.engine.*;

/** Component to generate a stream of 'n' packets, where 'n' is
* specified in an InitializationConnection.
*/
@ComponentDescription("Generates stream of packets under control of a counter")
@OutPort(value = "OUT", description = "Generated stream", type = String.class)
@InPort(value = "COUNT", description = "Count of packets to be generated",
     type = String.class)
public class Generate extends Component {

  static final String copyright = "Copyright 2007, 2008, J. Paul Morrison.  At your option, you may copy, "
      + "distribute, or make derivative works under the terms of the Clarified Artistic License, "
      + "based on the Everything Development Company's Artistic License.  A document describing "
      + "this License may be found at http://www.jpaulmorrison.com/fbp/artistic2.htm. "
      + "THERE IS NO WARRANTY; USE THIS PRODUCT AT YOUR OWN RISK.";

  OutputPort outport;

  InputPort count;

  @Override
  protected void execute() {
    Packet ctp = count.receive();
    if (ctp == null) {
      return;
    }
    count.close();

    String cti = (String) ctp.getContent();
    cti = cti.trim();
    int ct = 0;
    try {
      ct = Integer.parseInt(cti);
    } catch (NumberFormatException e) {
      e.printStackTrace();
    }
    drop(ctp);

    for (int i = 0; i < ct; i++) {
      int j = ct - i;
      Integer j2 = new Integer(j);
      String s = j2.toString();
      if (j < 10) {
        s = "0" + s;
      }
      if (j < 100) {
        s = "0" + s;
      }
      s = s + "abc";

      Packet p = create(s);
      outport.send(p);

    }

  }

  @Override
  protected void openPorts() {
    outport = openOutput("OUT");    
    count = openInput("COUNT");   
  }
}
