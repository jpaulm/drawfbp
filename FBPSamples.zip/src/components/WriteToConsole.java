package components;

import com.jpmorrsn.fbp.engine.*;


/**
 * Component to write data to the console, using a stream of packets. It is
 * specified as "must run" so that the output file will be cleared even if no
 * data packets are input.
 */
@ComponentDescription("Write stream of packets to console")
@InPort(value="IN", description="Packets to be displayed", type=String.class)
@OutPort(value = "OUT", optional = true, description="Output port, if connected", type=String.class)

@MustRun
public class WriteToConsole extends Component {

	static final String copyright = "Copyright 2007, 2008, 2009, J. Paul Morrison.  At your option, you may copy, "
			+ "distribute, or make derivative works under the terms of the Clarified Artistic License, "
			+ "based on the Everything Development Company's Artistic License.  A document describing "
			+ "this License may be found at http://www.jpaulmorrison.com/fbp/artistic2.htm. "
			+ "THERE IS NO WARRANTY; USE THIS PRODUCT AT YOUR OWN RISK.";

	InputPort inport;
	
	double _timeout = 3.0; // 3 secs
	 OutputPort outport;

	protected void execute() {
		Packet p;

		while ((p = inport.receive()) != null) {
			longWaitStart(_timeout);
			// sleep(5000L); //force timeout - testing only
			System.out.println((String) (p.getContent()));
			longWaitEnd();
			  if (outport.isConnected()) {
			        outport.send(p);
			      } else {
			        drop(p);
			      }
		}

	}
/*
	public Object[] introspect() {
		return new Object[] {
				"transmits its input to the console as lines ",
				"IN", "input", String.class, "lines to be written" };
	}
*/
	protected void openPorts() {
		inport = openInput("IN");
	
		outport = openOutput("OUT");

	}
}
