package test.networks; 
import com.jpmorrsn.fbp.engine.*; 
 public class TestMplex extends Network {
String description = " ";
protected void define() throws Throwable { 
component("Load_ Balance", components.LoadBalance.class); 
component("Testing_2", components.Generate.class); 
component("_Random _ Delay #2", components.RandomDelay.class); 
component(" _Show Text#2", components.ShowText.class); 
component("_Random_ Delay#1", components.RandomDelay.class); 
component("_Show Text#1", components.ShowText.class); 
component("_Random _ Delay #3", components.RandomDelay.class); 
component("_Show Text#3", components.ShowText.class); 
connect(component("Load_ Balance"), port("OUT[2]"), component("_Random _ Delay #3"), port("IN")); 
connect(component("Testing_2"), port("OUT"), component("Load_ Balance"), port("IN")); 
connect(component("Load_ Balance"), port("OUT[0]"), component("_Random_ Delay#1"), port("IN")); 
connect(component("Load_ Balance"), port("OUT[1]"), component("_Random _ Delay #2"), port("IN")); 
connect(component("_Random _ Delay #2"), port("OUT"), component(" _Show Text#2"), port("IN")); 
initialize("200", component("Testing_2"), port("COUNT")); 
connect(component("_Random _ Delay #3"), port("OUT"), component("_Show Text#3"), port("IN")); 
connect(component("_Random_ Delay#1"), port("OUT"), component("_Show Text#1"), port("IN")); 

 } 
public static void main(String[] argv) { 
 new TestMplex().go(); 
} 
 
}
