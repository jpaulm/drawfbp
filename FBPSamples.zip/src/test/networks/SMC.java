package test.networks; 
import com.jpmorrsn.fbp.engine.*; 
 public class SMC extends Network {
String description = " ";
protected void define() throws Throwable { 
component("_Start", components.Kick.class); 
component("Load_ Balance", components.LoadBalance.class); 
int X$0_count =  12 ;      //  multiplex counter for Show _ Text
for (int i = 0; i < X$0_count; i++)
component("Show _ Text:" + i, components.ShowText.class); 
component("Discard", components.Discard.class); 
for (int i = 0; i < X$0_count; i++)
connect(component("Show _ Text:" + i), port("OUT"), component("Discard"), port("IN")); 
connect(component("_Start"), port("OUT"), component("Load_ Balance"), port("IN")); 
for (int i = 0; i < X$0_count; i++)
connect(component("Load_ Balance"), port("OUT",i), component("Show _ Text:" + i), port("IN")); 

 } 
public static void main(String[] argv) { 
 new SMC().go(); 
} 
 
}
