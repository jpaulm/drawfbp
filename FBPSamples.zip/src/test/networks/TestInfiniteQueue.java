package test.networks; 
import com.jpmorrsn.fbp.engine.*; 
 public class TestInfiniteQueue extends Network {
String description = " t i q";
protected void define() throws Throwable { 
component("____ Generate", components.Generate.class); 
component("__ Infinite__  Queue", test.networks.InfiniteQueue.class); 
component("____  Display", components.WriteToConsole.class); 
connect(component("__ Infinite__  Queue"), port("OUT"), component("____  Display"), port("IN")); 
connect(component("____ Generate"), port("OUT"), component("__ Infinite__  Queue"), port("IN")); 
initialize("100", component("____ Generate"), port("COUNT")); 
initialize("temp.data", component("__ Infinite__  Queue"), port("TEMPFILENAME")); 

 } 
public static void main(String[] argv) { 
 new TestInfiniteQueue().go(); 
} 
 
}
