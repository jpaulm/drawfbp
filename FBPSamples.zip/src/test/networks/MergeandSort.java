package test.networks; 
import com.jpmorrsn.fbp.engine.*; 
 public class MergeandSort extends Network {
String description = "Merge and Sort Network";
protected void define() throws Throwable { 
component("_ Discard", components.Discard.class); 
component("_Write text_ to pane", components.ShowText.class); 
component("_ Sort", components.Sort.class); 
component("_ Generate _  1st group", components.Generate.class); 
component("_ Generate_  2nd group", components.Generate.class); 
initialize(new Integer(100), component("_ Generate _  1st group"), port("COUNT")); 
connect(component("_ Generate_  2nd group"), port("OUT"), component("_ Sort"), port("IN")); 
connect(component("_ Generate _  1st group"), port("OUT"), component("_ Sort"), port("IN")); 
connect(component("_Write text_ to pane"), port("OUT"), component("_ Discard"), port("IN")); 
initialize("Sorted Data", component("_Write text_ to pane"), port("TITLE")); 
connect(component("_ Sort"), port("OUT"), component("_Write text_ to pane"), port("IN")); 
initialize(new Integer(100), component("_ Generate_  2nd group"), port("COUNT")); 

 } 
public static void main(String[] argv) { 
 new MergeandSort().go(); 
} 
 
}
