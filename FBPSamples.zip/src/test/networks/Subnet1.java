package test.networks; 
import com.jpmorrsn.fbp.engine.*; 
@InPort("IN")
@OutPort("OUT")
public class Subnet1 extends SubNet {
String description = " ";
protected void define() throws Throwable { 
component("__ Infinite__  Queue", test.networks.InfiniteQueue.class); 
component("SUBIN", SubIn.class); 
initialize("IN", component("SUBIN"), port("NAME")); 
component("SUBOUT", SubOut.class); 
initialize("OUT", component("SUBOUT"), port("NAME")); 
connect(component("SUBIN"), port("OUT"), component("__ Infinite__  Queue"), port("IN")); 
connect(component("__ Infinite__  Queue"), port("OUT"), component("SUBOUT"), port("IN")); 
initialize("temp.data", component("__ Infinite__  Queue"), port("OUT")); 
} 
 
public Object[] introspect() { 
return new Object[] {
"????"
 , "IN", "input", Object.class    // <== Change if desired
, "OUT", "output", Object.class   // <==  Change if desired
};
}
}
