package test.networks; 
import com.jpmorrsn.fbp.engine.*; 
 public class MergeSortDrop extends Network {
String description = "Merge and Sort Network";
protected void define() throws Throwable { 
component("__ Generate", components.Generate.class); 
component("__ Generate2", components.Generate.class); 
component("__  Sort", components.Generate.class); 
component("__ Discard", components.Discard.class); 
connect(component("__ Generate2"), port("OUT"), component("__  Sort"), port("IN")); 
initialize(new Integer(100), component("__ Generate"), port("COUNT")); 
connect(component("__ Generate"), port("OUT"), component("__  Sort"), port("IN")); 
initialize(new Integer(100), component("__ Generate2"), port("COUNT")); 
connect(component("__  Sort"), port("OUT"), component("__ Discard"), port("IN")); 

 } 
public static void main(String[] argv) { 
 new MergeSortDrop().go(); 
} 
 
}
